# msk_modelling_python/msk_modelling_python/your_module.py





def greet():
    print("Are you ready to run openSim?!")

if __name__ == "__main__":
    greet()