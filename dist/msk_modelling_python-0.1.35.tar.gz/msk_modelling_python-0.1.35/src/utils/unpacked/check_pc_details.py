import platform

print(platform.machine())
print(platform.version())
print(platform.uname())
print(platform.system())
print(platform.processor())