import msk_modelling_python as msk


bops_set = msk.bp.get_bops_settings()

print(bops_set['current_project_folder'])
print(bops_set['jsonfile'])



# msk.bp.select_new_project_folder()

# select subjects
# msk.bp.select_subjects()

# select task 

# determine model inuts

# compare with database 

# output results