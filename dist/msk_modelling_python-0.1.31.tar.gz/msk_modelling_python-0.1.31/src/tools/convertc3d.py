from msk_modelling_python.src.tools import bops

c3d_data = bops.reader().c3d()
print(c3d_data.path)